# grad_routing/__init__.py

from .about import pretty_print as about
from .about import get_metadata

# Optional TensorFlow import (user installs manually)
try:
    import tensorflow as tf
except ImportError:
    raise ImportError(
        "TensorFlow is required but not installed.\n"
        "Please install it manually:\n\n"
        "    pip install tensorflow\n"
    )

# Import compiled Cython module
try:
    from .grad_routing import *
except ImportError as e:
    raise ImportError(
        "Could not import compiled module 'grad_routing'. "
        "Make sure the wheel is compiled properly."
    )

__all__ = [
    "about",
    "get_metadata",
    "topological_tiers",
    "xla_optimize_tiers",
    "differentiable_accuflux",
]
