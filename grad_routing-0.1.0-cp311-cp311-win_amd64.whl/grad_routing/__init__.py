# grad_routing/__init__.py

# -------------------------
# Expose about.py functions
# -------------------------
from .about import pretty_print as about
from .about import get_metadata

# -------------------------
# Import compiled Cython module functions
# -------------------------
# This assumes grad_routing.cp310-win_amd64.pyd contains topological_tiers and other functions
try:
    from .grad_routing import *
except ImportError as e:
    raise ImportError(
        "Could not import compiled module 'grad_routing'. "
    )

# -------------------------
# Optional: list all public symbols for autocomplete and help()
# -------------------------
__all__ = [
    "about",
    "get_metadata",
    "topological_tiers",
    "xla_optimize_tiers",
    "differentiable_accuflux"
    # add other functions you expose from grad_routing.pyx
]
