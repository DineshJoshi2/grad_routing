"""
grad_routing: High-performance differentiable & XLA-optimized flow-routing utilities

This package provides fast, Cython-accelerated, and XLA-compatible routing
functions for any acyclic flow network. It supports PCRaster-style LDD grids
and is designed for large-scale, GPU-accelerated, differentiable flow
accumulation in research and ML workflows.

Author: Dinesh Joshi
Email: joshidinesh0227@gmail.com
License: Licensed under the Apache License 2.0.
Copyright (c) 2025
"""

__package_name__ = "grad_routing"
__author__ = "Dinesh Joshi"
__email__ = "joshidinesh0227@gmail.com"
__license__ = "Licensed under the Apache License 2.0."
__version__ = "0.1.0"
__copyright__ = "© 2025 Dinesh Joshi"

__description__ = (
    "High-performance, XLA-optimized, Cython-accelerated routing utilities "
    "for acyclic flow networks. Supports PCRaster-style LDD grids with codes "
    "1–9 (1–4,6–9 for directional flow; 5 for no-flow / outlet)."
)

__keywords__ = [
    "routing",
    "flow accumulation",
    "differentiable modeling",
    "XLA",
    "Cython",
    "PCRaster",
    "LDD",
    "acyclic networks",
    "environmental modeling",
]

def get_metadata() -> dict:
    """Return package metadata as a dictionary."""
    return {
        "name": __package_name__,
        "author": __author__,
        "email": __email__,
        "version": __version__,
        "license": __license__,
        "description": __description__,
        "keywords": __keywords__,
    }


def pretty_print() -> str:
    """Return a clean multi-line metadata summary for users."""
    meta = get_metadata()
    return f"""
Package      : {meta['name']}
Author       : {meta['author']}
Email        : {meta['email']}
Version      : {meta['version']}
License      : {meta['license']}
Copyright    : {__copyright__}

Description:
    {meta['description']}

Keywords:
    {", ".join(meta['keywords'])}

Usage Notes:
    • Suitable for any acyclic flow network
    • XLA-optimized and GPU-compatible
    • Supports PCRaster-style LDD with:
        - Codes 1–4, 6–9: directional flow to neighbor
        - Code 5       : outlet / no-flow / sink cell
    • Designed for research, ML hydrology, DAG simulations, and environmental modeling

"""


if __name__ == "__main__":
    print(pretty_print())
